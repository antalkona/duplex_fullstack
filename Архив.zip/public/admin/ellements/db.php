<?php
    define('DB_HOST', 'duplex.zentas.ru')
    define('DBB_HOST', 'duplex.zentas.ru')


?>